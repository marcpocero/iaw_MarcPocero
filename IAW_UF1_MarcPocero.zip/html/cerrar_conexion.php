<?php
	mysqli_close($conection);
?>
