<?php
	$host = "localhost";
	$usuariodb = "root";
	$clavedb = "marcpocero";
	$basededatos = "AP2";
	$conection = new mysqli($host,$usuariodb,$clavedb,$basededatos);
	if ($conection->connect_errno) {
	    echo "Nuestro sitio tiene fallos.";
	exit();
	}
?>
