<?php
	$host = "localhost";
	$usuariodb = "root";
	$clavedb = "marcpocero";
	$basededatos = "AP2";
	$tabla_db1 = "incidencies";
	$conection = new mysqli($host,$usuariodb,$clavedb,$basededatos);
	if ($conection->connect_errno) {
	    echo "Nuestro tiene fallos.";
	exit();
	}
?>
